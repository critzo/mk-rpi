/*
 * Public domain.
 */
#ifndef MEASUREMENT_KIT_PORTABLE_ARPA_INET_H
#define MEASUREMENT_KIT_PORTABLE_ARPA_INET_H

#ifndef _WIN32
#include <arpa/inet.h>
#endif

#endif
