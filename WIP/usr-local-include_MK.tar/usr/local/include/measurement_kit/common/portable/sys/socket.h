/*
 * Public domain.
 */
#ifndef MEASUREMENT_KIT_PORTABLE_SYS_SOCKET_H
#define MEASUREMENT_KIT_PORTABLE_SYS_SOCKET_H

#ifndef _WIN32
#include <sys/socket.h>
#endif

#endif
