/*
 * Public domain.
 */
#ifndef MEASUREMENT_KIT_PORTABLE_NETINET_IN_H
#define MEASUREMENT_KIT_PORTABLE_NETINET_IN_H

#ifndef _WIN32
#include <netinet/in.h>
#endif

#endif
