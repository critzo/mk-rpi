/*
 * Public domain.
 */
#ifndef MEASUREMENT_KIT_PORTABLE_SYS_TIME_H
#define MEASUREMENT_KIT_PORTABLE_SYS_TIME_H

#ifndef _WIN32
#include <sys/time.h>
#endif

#endif
