/*
 * Public domain.
 */
#ifndef MEASUREMENT_KIT_PORTABLE_NETINET_TCP_H
#define MEASUREMENT_KIT_PORTABLE_NETINET_TCP_H

#ifndef _WIN32
#include <netinet/tcp.h>
#endif

#endif
