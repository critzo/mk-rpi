/*
 * Public domain.
 */
#ifndef MEASUREMENT_KIT_PORTABLE_SYS_TYPES_H
#define MEASUREMENT_KIT_PORTABLE_SYS_TYPES_H

#ifndef _WIN32
#include <sys/types.h>
#endif

#endif
