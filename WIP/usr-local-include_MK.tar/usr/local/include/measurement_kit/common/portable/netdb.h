/*
 * Public domain.
 */
#ifndef MEASUREMENT_KIT_PORTABLE_NETDB_H
#define MEASUREMENT_KIT_PORTABLE_NETDB_H

#ifndef _WIN32
#include <netdb.h>
#endif

#endif
